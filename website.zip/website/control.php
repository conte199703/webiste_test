<?php

	$con = mysqli_connect('localhost','root');
	// $con1 = mysqli_connect('localhost','root');
	mysqli_select_db($con, 'testreg');
	// mysqli_select_db($con1, 'testreg');
	
	// $consmingg = "SELECT CodArt, CodFor FROM consmin";
	// $featuredconsmin = $con1->query($consmingg);
	// while (($consmin = mysqli_fetch_assoc($featuredconsmin))){
		// if ($consmin["CodArt"]=1){
			// $cf1 = $consmin["CodFor"];
			// $tx1 = "Fornitore con tempo di consegna minore";
		// }
			// else if ($consmin["CodArt"] = 2) {
				// $cf2 = $consmin["CodFor"];
				
			// }
				// else if ($consmin["CodArt"] = 3) {
					// $cf3 = $consmin["CodFor"];
				// }
	// }
	// echo "$cf1";
	// echo "$cf2";
	// echo "$cf3";
	$search = $_GET["desart"];
	$sql = str_replace("term", $search, "SELECT * 
	FROM magazzino AS A 
	INNER JOIN articolo AS B ON A.CodArt = B.id 
	INNER JOIN fornitore AS C ON A.CodFor = C.id
	WHERE Des LIKE'%term%'");
	$featured = $con->query($sql);
	$qtaor = $_GET["qtaor"];
	if ($qtaor == null || $qtaor < 1) {
		$qtaor = 0;
		}	
	?>


<!DOCTYPE html>
<html>
<head>
	<title> Different Suppliers Shop </title>
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<script src="https://ajax.com.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
	<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Different Supplier Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
      </li>
      
    </ul>
  </div>
</nav>
<div class="col-md-2"></div>

	<div class"col-md-8">
		<div class="row">
			<h2 class="text-center">Top Products</h2> <br> <br> <br>
			<?php 
			
				while(($product = mysqli_fetch_assoc($featured))):
			$bool = 0
			?>
			<?php if (($qtaor <= $product["Qta"])):
			?>
			<?php if (($product["CodFor"] = 1) && ($product["Prezzo"] * $qtaor >= 1000)){
				$price = $product["Prezzo"] * $qtaor * 95 / 100;
				$sconto = "Sconto del 5% per ordini di importo pari o superiore a 1000€";
			}
				else if (($product["CodFor"] = 2) && ($qtaor >= 5) && ($qtaor < 10)) {
					$price = $product["Prezzo"] * $qtaor * 97 / 100;
					$sconto = "Sconto del 5% per ordini pari o superiori a 5 unità";
				}
				else if (($product["CodFor"] = 2) && ($qtaor >= 10)) {
					$price = $product["Prezzo"] * $qtaor * 95 / 100;
					$sconto = "Sconto del 5% per ordini pari o superiori a 10 unità";
				}
				else if (($product["CodFor"] = 3) && ($product["Prezzo"] * $qtaor >= 1000)) {
					$price = $product["Prezzo"] * $qtaor * 95 / 100;
					$sconto = "Sconto del 5% per ordini pari o superiori a 1000€";
						if (date("m") == "09") {
							$price = $price * 98 / 100;
							$sconto = "Sconto del 5% + 2% per ordini pari o superiori a 1000€ effettuati in settembre";
						}
				}
				else {
					$price = $product["Prezzo"];
				    $sconto = "";
				}
								
					
			?>
			<div class="col-md-5" align="center">
				<h4> <?= $product['Des'];?></h4>
				<img src="<?= $product['Img'];?>" alt="<?= $product['Des']; ?> width="400" height="500" />
				<p class="lprice"><?= $product['RagSoc'];?></p>
				<p class="lprice">€ <?= $product['Prezzo'];?> cad.</p>
				<p class="lprice">Qtà richiesta: <?= $qtaor;?> Pz.</p>
				<p class="lprice">Tempo di consegna <?= $product['Cons'];?> gg</p>
				<p class="lprice">Tot. € <?php echo "$price";?> cad.</p>
				<p class="lprice"><?php echo "$sconto";?></p>
				<!-- <h5>
				<?php 
				// if (( $product["CodFor"] = 1) && ($product["CodArt"] = 1)){
						// echo "$tx1";
				// }
				// else if (($cf2 = $product["CodFor"]) && ($product["CodArt"] = 2)) {
					// echo "Fornitore con tempo di consegna minore";
				// }
				// else if (($cf3 = $product["CodFor"]) && ($product["CodArt"] = 3)){
					// echo "Fornitore con tempo di consegna minore";
				// }
				 ?>
						// </h5>-->
				
		</div>
	<?php endif; ?>					
	<?php endwhile; ?>
		
	</div>
	</div>
	</body> 
</html>
