<!DOCTYPE html>
<html>
<head>
	<title> Different Suppliers Shop </title>
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<script src="https://ajax.com.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
	<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Different Supplier Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      
    </ul>
  </div>
</nav>
<br>
<br>
<br>
<form action="control.php" method="get" align="center">
  <label for="desart">Cerca:</label>
  <input type="text" id="desart" name="desart"><br><br>
  <label for="qtaor">Quantità da ordinare:</label>
  <input type="number" id="qtaor" name="qtaor">
  <input type="submit">
</form>

	</body> 
</html>